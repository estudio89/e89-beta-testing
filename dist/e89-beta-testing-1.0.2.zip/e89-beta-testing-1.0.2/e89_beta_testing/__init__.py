__VERSION__ = "1.0.2"
default_app_config = 'e89_beta_testing.apps.BetaTestingConfig'
